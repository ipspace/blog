These files implement the dns package from Tcllib on Cisco IOS. To use the
dns package, follow these steps:

* Unpack the ZIP archive into a directory on your workstation
* Transfer all the source files into a directory on your router (for example, flash:tcl).
* Configure "scripting tcl init flash:tcl/pkgIndex.tcl". Replace the flash:tcl/ path with
  the path to the source files.
* Now you can use the dns package in your scripts with the "package require dns" Tcl command.

Limitations:

* The DNS package supports only TCP transport
* You have to use an external DNS server, opening a TCP session to the router itself does not work.

NOTE: Read the tcllib.sourceforge.net for licensing information